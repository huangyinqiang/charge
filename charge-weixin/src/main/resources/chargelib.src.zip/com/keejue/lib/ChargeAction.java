/*    */ package com.keejue.lib;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.PrintStream;
/*    */ import org.apache.commons.httpclient.HttpClient;
/*    */ import org.apache.commons.httpclient.HttpException;
/*    */ import org.apache.commons.httpclient.methods.PostMethod;
/*    */ import org.apache.commons.httpclient.params.HttpClientParams;
/*    */ 
/*    */ public class ChargeAction
/*    */ {
/* 11 */   private static String chargeURL = "http://116.255.146.9:18646/socketServerController/doCharge.do";
/*    */ 
/*    */   public static String chargeTo(String deviceId, String channelNum, String chargeTime)
/*    */     throws Exception
/*    */   {
/* 23 */     String responseMsg = "";
/* 24 */     HttpClient httpClient = new HttpClient();
/* 25 */     httpClient.getParams().setContentCharset("GBK");
/* 26 */     PostMethod postMethod = new PostMethod(chargeURL);
/* 27 */     postMethod.addParameter("devicelId", deviceId);
/* 28 */     postMethod.addParameter("channelNum", channelNum);
/* 29 */     postMethod.addParameter("chargeTime", chargeTime);
/*    */     try {
/* 31 */       httpClient.executeMethod(postMethod);
/* 32 */       ByteArrayOutputStream out = new ByteArrayOutputStream();
/* 33 */       InputStream in = postMethod.getResponseBodyAsStream();
/* 34 */       int len = 0;
/* 35 */       byte[] buf = new byte[1024];
/* 36 */       while ((len = in.read(buf)) != -1) {
/* 37 */         out.write(buf, 0, len);
/*    */       }
/* 39 */       responseMsg = out.toString("UTF-8");
/*    */     } catch (HttpException e) {
/* 41 */       e.printStackTrace();
/*    */     } catch (IOException e) {
/* 43 */       e.printStackTrace();
/*    */     } finally {
/* 45 */       postMethod.releaseConnection();
/*    */     }
/* 47 */     return responseMsg;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) {
/*    */     try {
/* 52 */       String s = chargeTo("356566070540042", "2", "100");
/* 53 */       System.out.println(s);
/*    */     } catch (Exception e) {
/* 55 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\360极速浏览器下载\Server\WEB\Tomcat8.5_WEB\webapps\weixin\WEB-INF\classes\chargelib.jar
 * Qualified Name:     com.keejue.lib.ChargeAction
 * JD-Core Version:    0.5.3
 */